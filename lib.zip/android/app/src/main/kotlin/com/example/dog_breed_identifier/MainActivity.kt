package com.example.dog_breed_identifier

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
