import 'dart:io';
import 'dart:typed_data'; // Adaugă pentru Float32List
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:image/image.dart' as img;
import 'package:flutter/services.dart';
import '../models/prediction.dart'; // Importă clasa Prediction

class MLService {
  static late Interpreter _interpreter;
  static late List<String> _labels;

  static Future<void> init() async {
    _interpreter = await Interpreter.fromAsset('models/dog_breed_model.tflite');
    final labelData = await rootBundle.loadString('models/labels.txt');
    _labels = labelData.split(',')
        .map((item) => item.trim())
        .where((item) => item.isNotEmpty)
        .toList();
  }

  static Future<List<Prediction>> predict(File imageFile) async {
    // 1. Preprocesare imagine
    final imageBytes = await imageFile.readAsBytes();
    final image = img.decodeImage(imageBytes)!;
    final resized = img.copyResize(image, width: 224, height: 224);
    final input = _imageToByteList(resized);

    // 2. Rulare model
    final output = List.filled(120, 0.0).reshape([1, 120]);
    _interpreter.run(input, output);

    // 3. Procesare rezultate
    return _processOutput(output[0]);
  }

  static Float32List _imageToByteList(img.Image image) {
    final inputBuffer = Float32List(1 * 224 * 224 * 3);
    var pixelIndex = 0;

    for (var y = 0; y < 224; y++) {
      for (var x = 0; x < 224; x++) {
        final pixel = image.getPixel(x, y);
        inputBuffer[pixelIndex++] = (pixel.r - 127.5) / 127.5; // Normalizare [-1, 1]
        inputBuffer[pixelIndex++] = (pixel.g - 127.5) / 127.5;
        inputBuffer[pixelIndex++] = (pixel.b - 127.5) / 127.5;
      }
    }
    return inputBuffer;
  }

  static List<Prediction> _processOutput(List<double> output) {
    final predictions = <Prediction>[];
    for (var i = 0; i < output.length; i++) {
      predictions.add(Prediction(
        breed: _labels[i],
        confidence: output[i],
      ));
    }
    predictions.sort((a, b) => b.confidence.compareTo(a.confidence));
    return predictions.take(3).toList();
  }
}