class Prediction {
  final String breed;
  final double confidence;

  Prediction({required this.breed, required this.confidence});
}