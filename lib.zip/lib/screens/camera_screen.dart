import 'package:flutter/material.dart';
import 'package:camera/camera.dart'; // Adaugă acest import
import '../services/ml_service.dart';

class CameraScreen extends StatefulWidget {
  @override
  _CameraScreenState createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  late CameraController _controller;
  bool _isCameraReady = false;

  @override
  void initState() {
    super.initState();
    _initCamera();
    MLService.init();
  }

  Future<void> _initCamera() async {
    try {
      final cameras = await availableCameras();
      _controller = CameraController(
        cameras[0], // Folosește camera din spate
        ResolutionPreset.medium,
      );

      await _controller.initialize();

      if (!mounted) return;

      setState(() => _isCameraReady = true);
    } catch (e) {
      print('Eroare camera: $e');
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_isCameraReady) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          CameraPreview(_controller), // Afișează previzualizarea camerei
          // Restul interfeței tale existente...
          SafeArea(
            child: Column(
              children: [
                // Buton back
                Align(
                  alignment: Alignment.topLeft,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.7),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(Icons.arrow_back, color: Colors.black),
                      ),
                    ),
                  ),
                ),
                Spacer(),
                // Container rezultate
                _buildResultsContainer(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResultsContainer() {
    return Container(
      // Implementare existentă a containerului cu rezultate
    );
  }
}